import numpy as np
import random
import math

# this function takes in a mean and a standard deviation and generates two noisy pixels at a time according to the Box-Muller algorithm
def box_muller(m, sigma):
    r = random.random()
    fi = random.random()
    z1 = np.sqrt(-2 * np.log(r)) * np.sin(2 * math.pi * fi)
    z2 = np.sqrt(-2 * np.log(r)) * np.cos(2 * math.pi * fi)
    
    x1 = m + z1 * sigma
    x2 = m + z2 * sigma

    return x1, x2


def generate_gaussian_noise(height, width, mean, std):
    # since Box-Muller calculates two pixels at once we can generate two pixels of the noisy image at a time.
    # but if the width of the original image is not even, then there will be an error
    # after we reach the last column of the image.
    # so we can add a column if the image has an odd length: width + (width % 2)
    noise = np.zeros((height, width + (width % 2)))

    # then for every 2 pixels in a row we can assign them to x1, x2 from the Box-Muller algorithm
    for i in range(height):
        for j in range(0, width + (width % 2), 2):
            noise[i, j], noise[i, j+1] = box_muller(mean, std)
    
    # then return all the rows of the image and all the columns up to width.
    # for a 512x513 image, width + (width % 2) = 514
    # and [:width] is all the columns up to and including 513 but not including 514.
    # for a 512x512 image, width + (width % 2) = 512, so [:width] is all the columns up to and including 512
    return noise[:, :width]


# this function takes an image, a mean and a standard deviation and applies additive Gaussian noise to the image
# note that here std should be a fraction of the original image's standard deviation: i.g. std=(0.2 * standard_deviation)
def gaussian_noise(img, mean, std):
    # use a copy to not mutate the original image and cast to float64
    img = img.copy().astype(np.float64)

    # generate a 2d array of noise
    noise = generate_gaussian_noise(height=img.shape[0], width=img.shape[1], mean=mean, std=std)

    # add the noise to the clean image
    # round and clip on [0, 255] then cast back to uint8
    return np.clip(np.round(img + noise - mean), 0, 255).astype(np.uint8)

